
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class StudentDataList {
     private ArrayList<StudentData> list1;
    int place;
    private StudentDataList()
    {
        list1=new ArrayList<StudentData>();
    }
    private static StudentDataList obj;
    public static StudentDataList getobject()
    {
        if(obj==null)
        {
            obj= new StudentDataList(); 
        }
       return obj;
    }
    public void add_data(StudentData s)
    {
        list1.add(s);
    }
    public ArrayList<StudentData> all_data()
    {
        return list1;
    }
    public void svaeData(StudentData s,int index){
        list1.add(index,s);
    }
    public void toTxtFile(){
        try{
        FileWriter myfile = new FileWriter("StudentDataList.txt");
            for (int i = 0; i < list1.size(); i++) {
                myfile.write("Student ID : "+list1.get(i).getStudent_id_2()+"\n"+
                             
                             "Questions from CLO 1 in Assessment 1 : "+list1.get(i).getA1_clo1_q()+"         "+"Obtained Marks : "+list1.get(i).getA1_clo1_m()+"\n"+                        
                             "Questions from CLO 2 in Assessment 1 : "+list1.get(i).getA1_clo2_q()+"         "+"Obtained Marks : "+list1.get(i).getA1_clo2_m()+"\n"+
                             "Questions from CLO 3 in Assessment 1 : "+list1.get(i).getA1_clo3_q()+"         "+"Obtained Marks : "+list1.get(i).getA1_clo3_m()+"\n"+
                             "Questions from CLO 1 in Assessment 2 : "+list1.get(i).getA2_clo1_q()+"         "+"Obtained Marks : "+list1.get(i).getA2_clo1_m()+"\n"+
                             "Questions from CLO 2 in Assessment 2 : "+list1.get(i).getA2_clo2_q()+"         "+"Obtained Marks : "+list1.get(i).getA2_clo2_m()+"\n"+
                             "Questions from CLO 3 in Assessment 2 : "+list1.get(i).getA2_clo3_q()+"         "+"Obtained Marks : "+list1.get(i).getA2_clo3_m()+"\n"+
                             "Questions from CLO 1 in Assessment 3 : "+list1.get(i).getA3_clo1_q()+"         "+"Obtained Marks : "+list1.get(i).getA3_clo1_m()+"\n"+
                             "Questions from CLO 2 in Assessment 3 : "+list1.get(i).getA3_clo2_q()+"         "+"Obtained Marks : "+list1.get(i).getA3_clo2_m()+"\n"+
                             "Questions from CLO 3 in Assessment 3 : "+list1.get(i).getA3_clo3_q()+"         "+"Obtained Marks : "+list1.get(i).getA3_clo3_m()+"\n");
                                     
            }
            myfile.flush();
            myfile.close();
        }catch(Throwable e){
        JOptionPane.showMessageDialog(null,"An Errror Occured");
    }
    }
    public void StudentDataList_loader() {
        try {
            String line = null;
            FileReader fr = new FileReader("StudentDataList.txt");
            BufferedReader br = new BufferedReader(fr);
            line = br.readLine();
            while (line != null) {
                if (line.contains("\n")) {
                    String[] arr = line.split("\n");
                    for (int i = 0; i < 9; i++) {
                        System.out.println(arr[i]);                      
                    }
                    System.out.print("\n");
                }
                line = br.readLine();
            }
        } catch (Exception e) {
            System.out.print("Kuch to garber ha");
        }

    }
}
