/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class Student {
    private String Student_Name;
    private String Student_ID;
    private int age;
    private String Email;
    private int Phone;
    private String Degree;
    private String Gender;

    public String getStudent_Name() {
        return Student_Name;
    }

    public String getStudent_ID() {
        return Student_ID;
    }

    public int getAge() {
        return age;
    }

    public void setStudent_Name(String Student_Name) {
        this.Student_Name = Student_Name;
    }

    public void setStudent_ID(String Student_ID) {
        this.Student_ID = Student_ID;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setPhone(int Phone) {
        this.Phone = Phone;
    }

    public void setDegree(String Degree) {
        this.Degree = Degree;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getEmail() {
        return Email;
    }

    public int getPhone() {
        return Phone;
    }

    public String getDegree() {
        return Degree;
    }

    public String getGender() {
        return Gender;
    }
    
}
