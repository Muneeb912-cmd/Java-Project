/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class Validators {
    public boolean validateRegistrationNumber(String regNo) {
    boolean flag = true;
    boolean flag1 = true;
    boolean flag2 = true;
    boolean flag3 = true;
    boolean flag4 = true;
    char[] ch_a = regNo.toCharArray();
    int size = ch_a.length;
    int i;
    for (i = 0; i < 3; i++) {
      if (ch_a[i] >= '0' || ch_a[i] <= '9') {
        flag1 = true;
      } else {
        flag1 = false;
      }
    }
    if (flag1) {
      if ((ch_a[5] == 'C') & (ch_a[6] <= 'S')) {
        flag2 = true;
      } else {
        flag2 = false;
      }
    }
    if (flag2) {
      for (i = 8; i < size; i++)
        if (ch_a[1] >= '0' || ch_a[1] <= '9') {
          flag3 = true;
        } else {
          flag3 = false;
        }
    }
    if (ch_a[4] == '-' && ch_a[7] <= '-') {
      flag4 = true;
    } else {
      flag4 = false;
    }
    if (flag1 && flag2 && flag3 && flag4) {
      flag = true;
    } else {
      flag = false;
    }
    return flag;
  } 
    public  boolean validateStudentName(String name) {
    boolean flag = true;
    char[] ch_a = name.toCharArray();
    int size = ch_a.length;
    if(size>=3){
    int i;
    for (i = 0; i < size; i++) {
      if ((ch_a[i] >= 'A' || ch_a[i] >= 'Z')||(ch_a[i] >= 'a' || ch_a[i] <= 'z')) {
        flag = true;
      } else {
        flag = false;
      }
    }
    
    }
    return flag;
  }
    public boolean ValidateStudentAge(String age)
    {
        boolean flag=true;
         char[] ch_a = age.toCharArray();
         int size = ch_a.length;
         if(size<=2)
         {
             for(int i=0;i<2;i++)
             {
                 if(ch_a[i]>='0'||ch_a[i]<='9')
                 {
                     flag=true;
                 }
                 else{
                     flag=false;
                 }
             }
         }
         else{
             flag=false;
         }
       return flag;      
    }
    public boolean ValidatePhoneNumber(String phone)
    {
       boolean flag=true;
         char[] ch_a = phone.toCharArray();
         int size = ch_a.length;
         if(size==11)
         {
             for(int i=0;i<10;i++)
             {
                 if(ch_a[i]>='0'||ch_a[i]<='9')
                 {
                     flag=true;
                 }
                 else{
                     flag=false;
                 }
             }
         }
         else{
             flag=false;
         }
       return flag;      
    }
   public boolean CLO_name_check(String CLO){
       boolean flag=true;
        char[] ch_a = CLO.toCharArray();
       int size = ch_a.length;
       for(int i=0;i<size;i++){
       if((ch_a[i]>='a'&&ch_a[i]<='z')||(ch_a[i]>='A'&&ch_a[i]<='Z')){
           flag=true;
       }else{
           flag=false;
       }
       }
   return flag;
   }
    
    
}
