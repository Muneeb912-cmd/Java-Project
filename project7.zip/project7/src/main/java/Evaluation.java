/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class Evaluation {
    
    private String q1;
    private String q2;
    private String q3;
    private String q1_rub;
    private String q2_rub;
    private String q3_rub;
    private String q1_comp;    
    private String q2_comp;
    private String q3_comp;
    private String q1_rublvl;
    private String q2_rublvl;
    private String q3_rublvl;
    private int q1_obtained;
    private int q2_obtained;
    private int q3_obtained;

    public int getQ1_obtained() {
        return q1_obtained;
    }

    public void setQ1_obtained(int q1_obtained) {
        this.q1_obtained = q1_obtained;
    }

    public int getQ2_obtained() {
        return q2_obtained;
    }

    public void setQ2_obtained(int q2_obtained) {
        this.q2_obtained = q2_obtained;
    }

    public int getQ3_obtained() {
        return q3_obtained;
    }

    public void setQ3_obtained(int q3_obtained) {
        this.q3_obtained = q3_obtained;
    }
    private String Stu_id;

    public String getStu_id() {
        return Stu_id;
    }

    public void setStu_id(String Stu_id) {
        this.Stu_id = Stu_id;
    }
    public String getQ1() {
        return q1;
    }

    public void setQ1(String q1) {
        this.q1 = q1;
    }

    public String getQ2() {
        return q2;
    }

    public void setQ2(String q2) {
        this.q2 = q2;
    }

    public String getQ3() {
        return q3;
    }

    public void setQ3(String q3) {
        this.q3 = q3;
    }

    public String getQ1_rub() {
        return q1_rub;
    }

    public void setQ1_rub(String q1_rub) {
        this.q1_rub = q1_rub;
    }

    public String getQ2_rub() {
        return q2_rub;
    }

    public void setQ2_rub(String q2_rub) {
        this.q2_rub = q2_rub;
    }

    public String getQ3_rub() {
        return q3_rub;
    }

    public void setQ3_rub(String q3_rub) {
        this.q3_rub = q3_rub;
    }

    public String getQ1_comp() {
        return q1_comp;
    }

    public void setQ1_comp(String q1_comp) {
        this.q1_comp = q1_comp;
    }

    public String getQ2_comp() {
        return q2_comp;
    }

    public void setQ2_comp(String q2_comp) {
        this.q2_comp = q2_comp;
    }

    public String getQ3_comp() {
        return q3_comp;
    }

    public void setQ3_comp(String q3_comp) {
        this.q3_comp = q3_comp;
    }

    public String getQ1_rublvl() {
        return q1_rublvl;
    }

    public void setQ1_rublvl(String q1_rublvl) {
        this.q1_rublvl = q1_rublvl;
    }

    public String getQ2_rublvl() {
        return q2_rublvl;
    }

    public void setQ2_rublvl(String q2_rublvl) {
        this.q2_rublvl = q2_rublvl;
    }

    public String getQ3_rublvl() {
        return q3_rublvl;
    }

    public void setQ3_rublvl(String q3_rublvl) {
        this.q3_rublvl = q3_rublvl;
    }

    
  
}
