
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.text.Document;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class Data {
     private ArrayList<Student> list;
     Student s;
    int place;
    private Data()
    {
        list=new ArrayList<Student>();
    }
    private static Data obj;
    public static Data getobject()
    {
        if(obj==null)
      {
            obj= new Data(); 
        }
       return obj;
    }
    public void add_data(Student c)
    {
        list.add(c);
    }
    public ArrayList<Student> all_data()
    {
        return list;
    }
    public void toTxtFile(){
        try{
        FileWriter myfile = new FileWriter("StudentData.txt");
            for (int i = 0; i < list.size(); i++) {
                myfile.write("Student Name  : "+list.get(i).getStudent_Name()+"\n"+
                             "Student ID    : "+list.get(i).getStudent_ID()+"\n"+
                             "Student Age   : "+list.get(i).getAge()+"\n"+
                             "Studnet Degree: "+list.get(i).getDegree() +"\n"+
                             "Student Gendet: "+list.get(i).getGender()+"\n"+
                             "Studnent Email: "+list.get(i).getEmail()+"\n\n");
            }
            myfile.flush();
            myfile.close();
    }catch(Throwable e){
        JOptionPane.showMessageDialog(null,"An Errror Occured");
    }
    }
  
}
