
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class EvaluationList {
   
     private ArrayList<Evaluation> list2;
     Student s;
    int place;
    private EvaluationList()
    {
        list2=new ArrayList<Evaluation>();
    }
    private static EvaluationList obj;
    public static EvaluationList getobject()
    {
        if(obj==null)
      {
            obj= new EvaluationList(); 
        }
       return obj;
    }
    public void add_data(Evaluation c)
    {
        list2.add(c);
    }
    public ArrayList<Evaluation> all_data()
    {
        return list2;
    }
    public void toTxtFile(){
        try{
            try (FileWriter myfile = new FileWriter("EvaluationData.txt")) {
                for (int i = 0; i < list2.size(); i++) {
                    myfile.write("Student ID: "+list2.get(i).getStu_id()+"\n"+
                                 list2.get(i).getQ1()+"\n"+list2.get(i).getQ2()+"\n"+list2.get(i).getQ3()+"\n"+
                                 "Qi Component Marks : "+list2.get(i).getQ1_comp()+"\n"+"Q1 Rubrics : "+list2.get(i).getQ1_rub()+"\n"+"Q1 Rubrics LVL : "+list2.get(i).getQ1_rublvl()+"\n"+
                                 "Q2 Component Marks : "+list2.get(i).getQ2_comp()+"\n"+"Q2 Rubrics : "+list2.get(i).getQ2_rub()+"\n"+"Q1 Rubrics LVL : "+list2.get(i).getQ2_rublvl()+"\n"+
                                 "Q3 Component Marks : "+list2.get(i).getQ3_comp()+"\n"+"Q3 Rubrics : "+list2.get(i).getQ3_rub()+"\n"+"Q3 Rubrics LVL : "+list2.get(i).getQ3_rublvl()+"\n");
                }
                myfile.flush();
            }
          }catch(IOException e){
        JOptionPane.showMessageDialog(null,"An Errror Occured");
    }
    }
     
}
