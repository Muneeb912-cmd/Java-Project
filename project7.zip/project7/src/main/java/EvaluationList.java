
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class EvaluationList {
   
     private ArrayList<Evaluation> list2;
     Student s;
    int place;
    private EvaluationList()
    {
        list2=new ArrayList<Evaluation>();
    }
    private static EvaluationList obj;
    public static EvaluationList getobject()
    {
        if(obj==null)
      {
            obj= new EvaluationList(); 
        }
       return obj;
    }
    public void add_data(Evaluation c)
    {
        list2.add(c);
    }
    public ArrayList<Evaluation> all_data()
    {
        return list2;
    }
    public void toTxtFile(){
        try{
        FileWriter myfile = new FileWriter("EvaluationData.txt");
            for (int i = 0; i < list2.size(); i++) {
                myfile.write("Student ID: "+list2.get(i).getStu_id()+"\n"+
                              list2.get(i).getQ1()+"\n"+"Component Marks : "+list2.get(i).getQ1_comp()+"\n"+
                              "Rublics : "+list2.get(i).getQ1_rub()+"\n"+"Rublics Level : "+list2.get(i).getQ1_rublvl()+
                                list2.get(i).getQ2()+"\n"+"Component Marks : "+list2.get(i).getQ2_comp()+"\n"+
                              "Rublics : "+list2.get(i).getQ2_rub()+"\n"+"Rublics Level : "+list2.get(i).getQ2_rublvl()+
                                list2.get(i).getQ3()+"\n"+"Component Marks : "+list2.get(i).getQ3_comp()+"\n"+
                              "Rublics : "+list2.get(i).getQ3_rub()+"\n"+"Rublics Level : "+list2.get(i).getQ3_rublvl());
            }
            myfile.flush();
            myfile.close();
          }catch(Throwable e){
        JOptionPane.showMessageDialog(null,"An Errror Occured");
    }
    }
     public void EvaluationList_loader() {
        try {
            String line = null;
            FileReader fr = new FileReader("EvaluationData.txt");
            BufferedReader br = new BufferedReader(fr);
            line = br.readLine();
            while (line != null) {
                if (line.contains("\n")) {
                    String[] arr = line.split("\n");
                    for (int i = 0; i < 9; i++) {
                        System.out.println(arr[i]);                      
                    }
                    System.out.print("\n");
                }
                line = br.readLine();
            }
        } catch (Exception e) {
            System.out.print("Kuch to garber ha");
        }

    }
}
