/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muneeb912
 */
public class StudentData {

   
    private String Student_id_2;
    private String CLO1_name;
    private String CLO2_name;
    private String CLO3_name;
    private String CLO1_rubrics;
    private String CLO2_rubrics;
    private String CLO3_rubrics;
    private int A1_clo1_q;
    private int A2_clo1_q;
    private int A3_clo1_q;
    private int A1_clo2_q;
    private int A2_clo2_q;
    private int A3_clo2_q;
    private int A1_clo3_q;
    private int A2_clo3_q;
    private int A3_clo3_q;
    private int A1_clo1_m;
    private int A2_clo1_m;
    private int A3_clo1_m;
    private int A1_clo2_m;
    private int A2_clo2_m;
    private int A3_clo2_m;
    private int A1_clo3_m;
    private int A2_clo3_m;
    private int A3_clo3_m;

    public int getA1_clo1_m() {
        return A1_clo1_m;
    }

    public void setA1_clo1_m(int A1_clo1_m) {
        this.A1_clo1_m = A1_clo1_m;
    }

    public int getA2_clo1_m() {
        return A2_clo1_m;
    }

    public void setA2_clo1_m(int A2_clo1_m) {
        this.A2_clo1_m = A2_clo1_m;
    }

    public int getA3_clo1_m() {
        return A3_clo1_m;
    }

    public void setA3_clo1_m(int A3_clo1_m) {
        this.A3_clo1_m = A3_clo1_m;
    }

    public int getA1_clo2_m() {
        return A1_clo2_m;
    }

    public void setA1_clo2_m(int A1_clo2_m) {
        this.A1_clo2_m = A1_clo2_m;
    }

    public int getA2_clo2_m() {
        return A2_clo2_m;
    }

    public void setA2_clo2_m(int A2_clo2_m) {
        this.A2_clo2_m = A2_clo2_m;
    }

    public int getA3_clo2_m() {
        return A3_clo2_m;
    }

    public void setA3_clo2_m(int A3_clo2_m) {
        this.A3_clo2_m = A3_clo2_m;
    }

    public int getA1_clo3_m() {
        return A1_clo3_m;
    }

    public void setA1_clo3_m(int A1_clo3_m) {
        this.A1_clo3_m = A1_clo3_m;
    }

    public int getA2_clo3_m() {
        return A2_clo3_m;
    }

    public void setA2_clo3_m(int A2_clo3_m) {
        this.A2_clo3_m = A2_clo3_m;
    }

    public int getA3_clo3_m() {
        return A3_clo3_m;
    }

    public void setA3_clo3_m(int A3_clo3_m) {
        this.A3_clo3_m = A3_clo3_m;
    }
     public void setStudent_id_2(String Student_id_2) {
        this.Student_id_2 = Student_id_2;
    }

    public String getStudent_id_2() {
        return Student_id_2;
    }
    public String getCLO1_name() {
        return CLO1_name;
    }

    public String getCLO2_name() {
        return CLO2_name;
    }

    public String getCLO3_name() {
        return CLO3_name;
    }

    public String getCLO1_rubrics() {
        return CLO1_rubrics;
    }

    public String getCLO2_rubrics() {
        return CLO2_rubrics;
    }

    public String getCLO3_rubrics() {
        return CLO3_rubrics;
    }

    public int getA1_clo1_q() {
        return A1_clo1_q;
    }

    public int getA2_clo1_q() {
        return A2_clo1_q;
    }

    public int getA3_clo1_q() {
        return A3_clo1_q;
    }

    public int getA1_clo2_q() {
        return A1_clo2_q;
    }

    public int getA2_clo2_q() {
        return A2_clo2_q;
    }

    public int getA3_clo2_q() {
        return A3_clo2_q;
    }

    public int getA1_clo3_q() {
        return A1_clo3_q;
    }

    public int getA2_clo3_q() {
        return A2_clo3_q;
    }

    public int getA3_clo3_q() {
        return A3_clo3_q;
    }

    public void setCLO1_name(String CLO1_name) {
        this.CLO1_name = CLO1_name;
    }

    public void setCLO2_name(String CLO2_name) {
        this.CLO2_name = CLO2_name;
    }

    public void setCLO3_name(String CLO3_name) {
        this.CLO3_name = CLO3_name;
    }

    public void setCLO1_rubrics(String CLO1_rubrics) {
        this.CLO1_rubrics = CLO1_rubrics;
    }

    public void setCLO2_rubrics(String CLO2_rubrics) {
        this.CLO2_rubrics = CLO2_rubrics;
    }

    public void setCLO3_rubrics(String CLO3_rubrics) {
        this.CLO3_rubrics = CLO3_rubrics;
    }

    public void setA1_clo1_q(int A1_clo1_q) {
        this.A1_clo1_q = A1_clo1_q;
    }

    public void setA2_clo1_q(int A2_clo1_q) {
        this.A2_clo1_q = A2_clo1_q;
    }

    public void setA3_clo1_q(int A3_clo1_q) {
        this.A3_clo1_q = A3_clo1_q;
    }

    public void setA1_clo2_q(int A1_clo2_q) {
        this.A1_clo2_q = A1_clo2_q;
    }

    public void setA2_clo2_q(int A2_clo2_q) {
        this.A2_clo2_q = A2_clo2_q;
    }

    public void setA3_clo2_q(int A3_clo2_q) {
        this.A3_clo2_q = A3_clo2_q;
    }

    public void setA1_clo3_q(int A1_clo3_q) {
        this.A1_clo3_q = A1_clo3_q;
    }

    public void setA2_clo3_q(int A2_clo3_q) {
        this.A2_clo3_q = A2_clo3_q;
    }

    public void setA3_clo3_q(int A3_clo3_q) {
        this.A3_clo3_q = A3_clo3_q;
    }
    
   
}
